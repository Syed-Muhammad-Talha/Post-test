# Migration Plan: Node.js + MongoDB → PHP (Laravel) + MySQL

## Project: Al Jawdah Al Mutamadah — Private Garage POS

### 1. Current State
- Frontend: React + Vite (`frontend/`)
- Backend: Node.js + Express + TypeScript (`backend/`)
- Database: MongoDB Atlas via Prisma
- 24 Prisma models (see `backend/prisma/schema.prisma`)

### 2. Target State
- Frontend: unchanged React + Vite
- Backend: Laravel 11 (PHP 8.2+) inside `backend/` (Node backend preserved as `backend-node/` reference until verified)
- Database: MySQL 8.0

### 3. Strategy
1. Keep Node backend untouched until Laravel backend is fully implemented & tested.
2. Scaffold Laravel into `backend-laravel/` first, then swap folders (or rename) to avoid data loss. Actually per requirement, new backend must be inside existing `backend/`. We will move Node backend to `backend-node-legacy/` only after Laravel is verified, then rename `backend-laravel` → `backend`.
3. Use Sanctum for token auth (Bearer tokens, matching frontend's `Authorization: Bearer` usage).
4. Preserve API response shape: `{ data: ... }` or `{ data, message }` so frontend `request()` keeps working (`data?.data !== undefined ? data.data : data`).
5. MySQL tables mirror Prisma models with snake_case columns; Eloquent models use `$fillable` and casts.

### 4. Database Schema Mapping (Prisma → MySQL)
All IDs: MongoDB cuid/ObjectId → MySQL `VARCHAR(36)` (UUID) or `BIGINT` auto-increment. We'll use `VARCHAR(36)` UUID to preserve referential mapping during data migration, with a `legacy_mongo_id` column for traceability.

Tables (24):
1. garage_settings
2. users (role enum: owner/manager/employee; status active/disabled)
3. customers
4. vehicles (FK customer_id)
5. categories
6. suppliers
7. products (FK category_id, supplier_id)
8. inventory_transactions (FK product_id)
9. purchases (FK supplier_id)
10. purchase_items (FK purchase_id, product_id)
11. labour_workers
12. labour_payments (FK worker_id)
13. repair_jobs (FK customer_id, vehicle_id, invoice_id nullable)
14. job_parts (FK job_id, product_id)
15. job_labours (FK job_id, worker_id)
16. job_photos (FK job_id)
17. invoices (FK customer_id, vehicle_id, job_card_id nullable)
18. invoice_items (FK invoice_id, product_id nullable)
19. payments (FK invoice_id)
20. expenses
21. workshop_rents
22. electricity_bills
23. license_records
24. oil_changes (FK vehicle_id, customer_id, oil_product_id nullable)
25. audit_logs (FK user_id)

Financial columns: DECIMAL(12,2). Dates: DATETIME with Asia/Dubai app tz. Indexes on FKs and unique fields (username, email, registration_number, sku, invoice_number, job_number).

### 5. Authentication
- Sanctum personal access tokens.
- Login accepts `username` or `email` + `password`.
- No public registration (admin creates users).
- Roles: owner, manager, employee. Middleware `role:`.

### 6. Data Migration
- Script `backend/database/migrate-mongo-to-mysql.php` (or Node script reading Mongo and writing MySQL) that:
  - Connects to Mongo Atlas (read-only) and MySQL.
  - Maps each collection → table, preserving IDs via `legacy_mongo_id`.
  - Handles missing/optional fields with defaults.
  - Idempotent (skip existing legacy_mongo_id).
  - Transactional per collection.
  - Produces verification report (counts per table, checksums).

### 7. Frontend Integration
- Set `VITE_API_BASE_URL` to Laravel base (e.g. `http://localhost:8000/api`).
- Laravel routes prefixed `/api`.
- Response envelope `{ data, message }` to match frontend.
- Sanctum token stored same localStorage keys.

### 8. Phases
- Phase A: Plan (this doc) ✓
- Phase B: Scaffold Laravel + migrations + models
- Phase C: Auth + core CRUD (customers, vehicles, products, suppliers, categories)
- Phase D: Purchases, inventory transactions
- Phase E: Invoices, payments
- Phase F: Repair jobs, job parts/labour/photos
- Phase G: Labour payroll
- Phase H: Expenses, rent, electricity, licenses
- Phase I: Oil changes, settings, dashboard, reports
- Phase J: Data migration scripts
- Phase K: Frontend wiring + testing

### 9. Testing
- Each module: create → persist → retrieve → update → persist → refresh → verify.
- Payroll, inventory, invoices, jobs, expenses, dashboard calculations.

### 10. Deliverables
- Laravel backend, migrations, models, controllers, services, routes
- Mongo→MySQL migration scripts + verification report
- Updated frontend API config
- .env.example, install docs, test report, file list

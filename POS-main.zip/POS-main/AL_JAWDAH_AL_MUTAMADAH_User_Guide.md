# AL JAWDAH AL MUTAMADAH - Automotive Garage POS & Workshop Management System
## User Guide

### Business Information
- **Business Name:** AL JAWDAH AL MUTAMADAH (الجودة المعتمدة)
- **Business Type:** Automotive Repair and Maintenance Garage
- **Location:** Dubai, UAE
- **Currency:** AED
- **Timezone:** Asia/Dubai
- **VAT Rate:** 5% (Configurable in SETTINGS)

---

## Workbook Structure

The system contains the following sheets:

1. **01. HOME** - Navigation and welcome screen
2. **02. DASHBOARD** - KPI overview with automated calculations
3. **03. POS** - Point of Sale for creating invoices
4. **04. SALES_INVOICES** - Sales transaction register
5. **05. CUSTOMERS** - Customer management
6. **06. VEHICLES** - Vehicle management with service history
7. **07. JOB_CARDS** - Workshop job cards and repair tracking
8. **08. SERVICE_HISTORY** - Complete vehicle service history
9. **09. INVENTORY** - Spare parts inventory management
10. **10. PURCHASES** - Purchase orders and supplier transactions
11. **11. SUPPLIERS** - Supplier management
12. **12. STOCK_MOVEMENTS** - Complete inventory audit trail
13. **13. LABOUR** - Labour charges and technician tracking
14. **14. EMPLOYEES** - Employee records
15. **15. SALARY_PAYMENTS** - Salary payment tracking
16. **16. DAILY_EXPENSES** - Daily operational expenses
17. **17. FIXED_EXPENSES** - Monthly fixed expenses
18. **18. CUSTOMER_PAYMENTS** - Customer payment receipts
19. **19. SUPPLIER_PAYMENTS** - Supplier payment records
20. **20. PROFIT_LOSS** - Profit & Loss statement
21. **21. FINANCIAL_REPORTS** - Financial reports and analytics
22. **22. AUDIT_LOG** - System audit trail
23. **23. SETTINGS** - System configuration

---

## Getting Started

### Daily Operations Workflow

1. **Customer Registration** - Add customers in `05. CUSTOMERS` sheet
2. **Vehicle Registration** - Add vehicles linked to customers in `06. VEHICLES`
3. **Create Job Card** - For workshop repairs, create in `07. JOB_CARDS`
4. **Parts & Labour** - Add parts from inventory and labour charges
5. **Complete Job** - Update job status to "Completed"
6. **Create Invoice** - Use `03. POS` to generate invoice
7. **Record Payment** - Track payments in `18. CUSTOMER_PAYMENTS`
8. **Update Inventory** - Purchases update stock automatically

---

## Key Features

### Point of Sale (POS)
- Select existing customers and vehicles
- Add multiple products and services
- Automatic price retrieval from inventory
- VAT calculation (configurable)
- Support for Cash, Card, Bank Transfer
- Partial and full payments
- Automatic inventory deduction on confirmed sales

### Inventory Management
- Automatic stock tracking
- Low stock alerts (configurable threshold)
- Stock value calculations
- Complete audit trail in STOCK_MOVEMENTS
- Prevents negative stock (configurable)

### Workshop Management
- Job card creation and tracking
- Parts usage tracking with automatic stock deduction
- Labour charge management
- Service history maintenance
- Technician assignment

### Financial Management
- Automated Profit & Loss calculations
- Customer receivables tracking
- Supplier payables tracking
- Expense management (daily and fixed)
- Salary payments

---

## Important Notes

- **Input Cells vs Formula Cells:** Cells with formulas should not be manually edited
- **Data Entry:** Use dropdowns where provided for consistency
- **IDs:** System uses unique IDs for all records
- **Empty Database:** Start with clean tables - no dummy data included
- **Backup:** Regularly backup this Excel file
- **Multi-user:** Excel is not suitable for simultaneous multi-user editing - use with caution
- **Audit Trail:** Important changes are logged in AUDIT_LOG sheet
- **Security:** Worksheet protection is available but not tamper-proof

---

## Configuration

Update `23. SETTINGS` sheet to configure:
- Business details
- Currency and timezone
- VAT rate
- ID prefixes
- Default payment methods
- Stock alert levels
- Financial year start

---

## Support

For questions or issues, refer to the formulas and structure within the workbook. All calculations are automated using Excel formulas.

**File:** AL_JAWDAH_AL_MUTAMADAH_Automotive_Garage_POS_System.xlsx
**Version:** 1.0
**Date Created:** November 2025

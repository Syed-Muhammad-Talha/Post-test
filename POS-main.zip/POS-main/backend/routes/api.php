<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\VehicleController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\InventoryTransactionController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\RepairJobController;
use App\Http\Controllers\JobPartController;
use App\Http\Controllers\JobLabourController;
use App\Http\Controllers\LabourWorkerController;
use App\Http\Controllers\LabourPaymentController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\WorkshopRentController;
use App\Http\Controllers\ElectricityBillController;
use App\Http\Controllers\LicenseRecordController;
use App\Http\Controllers\OilChangeController;
use App\Http\Controllers\GarageSettingController;

Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'app' => 'Private Garage POS & Workshop Engine (Dubai)',
        'currency' => 'AED',
        'timezone' => 'Asia/Dubai',
        'version' => '2.0.0',
    ]);
});

Route::post('/auth/login', [AuthController::class, 'login'])->name('login');
Route::post('/auth/users', [AuthController::class, 'register']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/auth/me', [AuthController::class, 'me']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::apiResource('customers', CustomerController::class);
    Route::apiResource('vehicles', VehicleController::class);
    Route::apiResource('categories', CategoryController::class);
    Route::apiResource('suppliers', SupplierController::class);
    Route::apiResource('products', ProductController::class);
    Route::apiResource('purchases', PurchaseController::class);
    Route::apiResource('inventory-transactions', InventoryTransactionController::class);
    Route::apiResource('invoices', InvoiceController::class);
    Route::apiResource('payments', PaymentController::class);
    Route::apiResource('jobs', RepairJobController::class);
    Route::post('job-parts', [JobPartController::class,'store']);
    Route::delete('job-parts/{id}', [JobPartController::class,'destroy']);
    Route::post('job-labours', [JobLabourController::class,'store']);
    Route::delete('job-labours/{id}', [JobLabourController::class,'destroy']);
    Route::apiResource('labour/workers', LabourWorkerController::class);
    Route::apiResource('labour/payments', LabourPaymentController::class);
    Route::apiResource('expenses', ExpenseController::class);
    Route::apiResource('workshop-rents', WorkshopRentController::class);
    Route::apiResource('electricity-bills', ElectricityBillController::class);
    Route::apiResource('license-records', LicenseRecordController::class);
    Route::apiResource('oil-changes', OilChangeController::class);
    Route::get('settings', [GarageSettingController::class,'show']);
    Route::put('settings', [GarageSettingController::class,'update']);
});

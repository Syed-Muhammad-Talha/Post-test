<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // garage_settings
        Schema::create('garage_settings', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('shop_name')->default('Al Jawdah Al Mutamadah');
            $table->string('garage_name')->default('Al Jawdah Al Mutamadah');
            $table->string('garage_owner_name')->default('Umair Ullah');
            $table->string('garage_phone')->default('+971 50 789 4521');
            $table->string('garage_email')->default('owner@Al Jawdah Al Mutamadah.ae');
            $table->string('address')->default('Dubai, UAE');
            $table->string('tagline')->nullable();
            $table->string('tax_number')->nullable();
            $table->string('currency')->default('AED');
            $table->decimal('default_tax_rate', 5, 2)->default(5.00);
            $table->string('invoice_prefix')->default('INV-2026-');
            $table->boolean('private_mode')->default(true);
            $table->boolean('setup_completed')->default(true);
            $table->integer('low_stock_threshold')->default(5);
            $table->integer('default_oil_interval_km')->default(5000);
            $table->integer('default_oil_interval_months')->default(3);
            $table->timestamps();
        });

        // users
        Schema::create('users', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('name');
            $table->string('username')->unique();
            $table->string('email')->unique();
            $table->string('phone')->nullable();
            $table->string('role')->default('employee');
            $table->string('status')->default('active');
            $table->string('password');
            $table->string('salt')->nullable();
            $table->timestamp('last_login')->nullable();
            $table->timestamps();
        });

        // customers
        Schema::create('customers', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('full_name');
            $table->string('phone');
            $table->string('alternate_phone')->nullable();
            $table->string('email')->nullable();
            $table->text('address')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        // vehicles
        Schema::create('vehicles', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('customer_id', 36);
            $table->string('registration_number')->unique();
            $table->string('make');
            $table->string('model');
            $table->integer('year')->nullable();
            $table->string('color')->nullable();
            $table->string('vin')->nullable();
            $table->string('engine_number')->nullable();
            $table->integer('current_mileage')->default(0);
            $table->string('fuel_type')->default('Petrol');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
        });

        // categories
        Schema::create('categories', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('name')->unique();
            $table->timestamps();
        });

        // suppliers
        Schema::create('suppliers', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('name');
            $table->string('phone')->nullable();
            $table->string('email')->nullable();
            $table->text('address')->nullable();
            $table->timestamps();
        });

        // products
        Schema::create('products', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('sku')->unique();
            $table->string('name');
            $table->string('category_id', 36)->nullable();
            $table->string('supplier_id', 36)->nullable();
            $table->string('brand')->default('Universal');
            $table->decimal('purchase_price', 12, 2)->default(0);
            $table->decimal('selling_price', 12, 2)->default(0);
            $table->integer('current_quantity')->default(0);
            $table->integer('min_stock_level')->default(5);
            $table->string('unit')->default('units');
            $table->string('shelf_location')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
            $table->foreign('category_id')->references('id')->on('categories')->nullOnDelete();
            $table->foreign('supplier_id')->references('id')->on('suppliers')->nullOnDelete();
        });

        // inventory_transactions
        Schema::create('inventory_transactions', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('product_id', 36);
            $table->string('type');
            $table->integer('quantity');
            $table->decimal('unit_cost', 12, 2)->default(0);
            $table->string('reference_id')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
        });

        // purchases
        Schema::create('purchases', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('invoice_number')->nullable();
            $table->string('supplier_id', 36)->nullable();
            $table->timestamp('date')->useCurrent();
            $table->decimal('total_amount', 12, 2)->default(0);
            $table->text('notes')->nullable();
            $table->string('created_by')->nullable();
            $table->timestamps();
            $table->foreign('supplier_id')->references('id')->on('suppliers')->nullOnDelete();
        });

        // purchase_items
        Schema::create('purchase_items', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('purchase_id', 36);
            $table->string('product_id', 36);
            $table->integer('quantity');
            $table->decimal('unit_cost', 12, 2);
            $table->decimal('total_cost', 12, 2);
            $table->timestamps();
            $table->foreign('purchase_id')->references('id')->on('purchases')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('products');
        });

        // labour_workers
        Schema::create('labour_workers', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('name');
            $table->string('phone');
            $table->string('position');
            $table->string('rate_type')->default('daily');
            $table->decimal('rate_amount', 12, 2)->default(0);
            $table->string('status')->default('active');
            $table->timestamps();
        });

        // labour_payments
        Schema::create('labour_payments', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('worker_id', 36);
            $table->timestamp('date')->useCurrent();
            $table->decimal('amount', 12, 2)->default(0);
            $table->string('payment_method')->default('Cash');
            $table->timestamp('period_start')->nullable();
            $table->timestamp('period_end')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('worker_id')->references('id')->on('labour_workers')->onDelete('cascade');
        });

        // repair_jobs
        Schema::create('repair_jobs', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('job_number')->unique();
            $table->string('customer_id', 36);
            $table->string('vehicle_id', 36);
            $table->timestamp('date')->useCurrent();
            $table->integer('mileage_in')->default(0);
            $table->text('customer_complaint');
            $table->text('diagnosis')->nullable();
            $table->text('work_required')->nullable();
            $table->string('status')->default('draft');
            $table->decimal('estimated_cost', 12, 2)->default(0);
            $table->decimal('final_cost', 12, 2)->default(0);
            $table->string('invoice_id', 36)->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('customer_id')->references('id')->on('customers');
            $table->foreign('vehicle_id')->references('id')->on('vehicles');
        });

        // job_parts
        Schema::create('job_parts', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('job_id', 36);
            $table->string('product_id', 36);
            $table->integer('quantity');
            $table->decimal('unit_cost', 12, 2);
            $table->decimal('unit_price', 12, 2);
            $table->decimal('total_cost', 12, 2);
            $table->decimal('total_price', 12, 2);
            $table->timestamps();
            $table->foreign('job_id')->references('id')->on('repair_jobs')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('products');
        });

        // job_labours
        Schema::create('job_labours', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('job_id', 36);
            $table->string('worker_id', 36);
            $table->integer('units')->default(1);
            $table->decimal('cost_to_shop', 12, 2)->default(0);
            $table->decimal('customer_charge', 12, 2)->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('job_id')->references('id')->on('repair_jobs')->onDelete('cascade');
            $table->foreign('worker_id')->references('id')->on('labour_workers');
        });

        // job_photos
        Schema::create('job_photos', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('job_id', 36);
            $table->string('photo_url');
            $table->string('caption')->nullable();
            $table->timestamps();
            $table->foreign('job_id')->references('id')->on('repair_jobs')->onDelete('cascade');
        });

        // invoices
        Schema::create('invoices', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('invoice_number')->unique();
            $table->string('job_card_id', 36)->nullable();
            $table->string('customer_id', 36);
            $table->string('vehicle_id', 36)->nullable();
            $table->timestamp('date')->useCurrent();
            $table->decimal('parts_total', 12, 2)->default(0);
            $table->decimal('labour_total', 12, 2)->default(0);
            $table->decimal('services_total', 12, 2)->default(0);
            $table->decimal('parts_cost', 12, 2)->default(0);
            $table->decimal('labour_cost', 12, 2)->default(0);
            $table->decimal('services_cost', 12, 2)->default(0);
            $table->decimal('discount', 12, 2)->default(0);
            $table->decimal('tax_rate', 5, 2)->default(0);
            $table->decimal('tax_amount', 12, 2)->default(0);
            $table->decimal('grand_total', 12, 2)->default(0);
            $table->decimal('paid_amount', 12, 2)->default(0);
            $table->decimal('balance_due', 12, 2)->default(0);
            $table->string('payment_status')->default('unpaid');
            $table->string('payment_method')->default('Cash');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('customer_id')->references('id')->on('customers');
            $table->foreign('vehicle_id')->references('id')->on('vehicles')->nullOnDelete();
        });

        // invoice_items
        Schema::create('invoice_items', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('invoice_id', 36);
            $table->string('type');
            $table->string('product_id', 36)->nullable();
            $table->string('name');
            $table->integer('quantity');
            $table->decimal('unit_price', 12, 2);
            $table->decimal('total_price', 12, 2);
            $table->decimal('unit_cost', 12, 2)->default(0);
            $table->decimal('total_cost', 12, 2)->default(0);
            $table->timestamps();
            $table->foreign('invoice_id')->references('id')->on('invoices')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('products')->nullOnDelete();
        });

        // payments
        Schema::create('payments', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('invoice_id', 36);
            $table->decimal('amount', 12, 2);
            $table->timestamp('payment_date')->useCurrent();
            $table->string('payment_method')->default('Cash');
            $table->string('reference_number')->nullable();
            $table->string('received_by');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('invoice_id')->references('id')->on('invoices')->onDelete('cascade');
        });

        // expenses
        Schema::create('expenses', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('title');
            $table->string('category');
            $table->string('type')->default('daily');
            $table->decimal('amount', 12, 2);
            $table->timestamp('date')->useCurrent();
            $table->string('payment_method')->default('Cash');
            $table->string('status')->default('Paid');
            $table->string('paid_by')->nullable();
            $table->string('recipient')->nullable();
            $table->string('receipt_number')->nullable();
            $table->text('notes')->nullable();
            $table->string('attachment')->nullable();
            $table->text('void_reason')->nullable();
            $table->string('linked_entity_id')->nullable();
            $table->string('linked_entity_type')->nullable();
            $table->timestamps();
        });

        // workshop_rents
        Schema::create('workshop_rents', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('month');
            $table->string('month_label');
            $table->decimal('amount', 12, 2);
            $table->decimal('paid_amount', 12, 2)->default(0);
            $table->timestamp('payment_date')->nullable();
            $table->string('payment_method')->default('Bank Transfer');
            $table->string('status')->default('Pending');
            $table->text('notes')->nullable();
            $table->string('attachment')->nullable();
            $table->timestamps();
        });

        // electricity_bills
        Schema::create('electricity_bills', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('billing_month');
            $table->string('month_label');
            $table->string('bill_number')->nullable();
            $table->decimal('previous_reading', 12, 2)->nullable();
            $table->decimal('current_reading', 12, 2)->nullable();
            $table->decimal('units_consumed', 12, 2)->default(0);
            $table->decimal('bill_amount', 12, 2);
            $table->decimal('paid_amount', 12, 2)->default(0);
            $table->timestamp('issue_date')->useCurrent();
            $table->timestamp('due_date')->nullable();
            $table->timestamp('payment_date')->nullable();
            $table->string('payment_method')->default('Bank Transfer');
            $table->string('status')->default('Unpaid');
            $table->text('notes')->nullable();
            $table->string('attachment')->nullable();
            $table->timestamps();
        });

        // license_records
        Schema::create('license_records', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('name');
            $table->string('license_number');
            $table->string('issuing_authority');
            $table->timestamp('issue_date')->nullable();
            $table->timestamp('expiry_date')->nullable();
            $table->decimal('renewal_cost', 12, 2);
            $table->timestamp('payment_date')->nullable();
            $table->string('payment_method')->default('Bank Transfer');
            $table->string('status')->default('Active');
            $table->text('notes')->nullable();
            $table->string('attachment')->nullable();
            $table->timestamps();
        });

        // oil_changes
        Schema::create('oil_changes', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('vehicle_id', 36);
            $table->string('customer_id', 36);
            $table->string('oil_product_id', 36)->nullable();
            $table->timestamp('service_date')->useCurrent();
            $table->integer('current_mileage');
            $table->integer('next_recommended_mileage');
            $table->timestamp('next_recommended_date')->nullable();
            $table->string('oil_brand');
            $table->string('oil_type');
            $table->decimal('oil_quantity', 8, 2);
            $table->string('oil_filter_part_number')->nullable();
            $table->string('technician_name');
            $table->decimal('cost_price', 12, 2)->default(0);
            $table->decimal('selling_price', 12, 2)->default(0);
            $table->string('status')->default('upcoming');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->foreign('vehicle_id')->references('id')->on('vehicles');
            $table->foreign('customer_id')->references('id')->on('customers');
            $table->foreign('oil_product_id')->references('id')->on('products')->nullOnDelete();
        });

        // audit_logs
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('user_id', 36);
            $table->string('user_name');
            $table->string('user_role');
            $table->string('module');
            $table->string('action');
            $table->string('record_id');
            $table->text('description');
            $table->string('ip_address')->nullable();
            $table->timestamp('timestamp')->useCurrent();
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    public function down(): void
    {
        $tables = ['audit_logs','oil_changes','license_records','electricity_bills','workshop_rents','expenses','payments','invoice_items','invoices','job_photos','job_labours','job_parts','repair_jobs','labour_payments','labour_workers','purchase_items','purchases','inventory_transactions','products','suppliers','categories','vehicles','customers','users','garage_settings'];
        foreach ($tables as $t) {
            Schema::dropIfExists($t);
        }
    }
};

<?php
namespace Database\Seeders;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['username' => 'umairullah'],
            [
                'id' => Str::uuid()->toString(),
                'name' => 'Umair Ullah',
                'email' => 'umairullah410446@gmail.com',
                'phone' => '03130931000',
                'role' => 'owner',
                'status' => 'active',
                'password' => Hash::make('Umairkhan123#'),
            ]
        );
    }
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Vehicle extends Model {
    protected $keyType = 'string'; public $incrementing = false;
    protected $fillable = ['id','customer_id','registration_number','make','model','year','color','vin','engine_number','current_mileage','fuel_type','notes'];
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
}

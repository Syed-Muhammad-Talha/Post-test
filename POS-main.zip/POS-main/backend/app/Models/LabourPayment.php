<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class LabourPayment extends Model {
    protected $table='labour_payments'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','worker_id','date','amount','payment_method','period_start','period_end','notes'];
    protected $casts=['amount'=>'decimal:2','date'=>'datetime','period_start'=>'datetime','period_end'=>'datetime'];
    public function worker(): BelongsTo { return $this->belongsTo(LabourWorker::class,'worker_id'); }
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class GarageSetting extends Model {
    protected $table='garage_settings'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','shop_name','garage_name','garage_owner_name','garage_phone','garage_email','address','tagline','tax_number','currency','default_tax_rate','invoice_prefix','private_mode','setup_completed','low_stock_threshold','default_oil_interval_km','default_oil_interval_months'];
    protected $casts=['default_tax_rate'=>'decimal:2','private_mode'=>'boolean','setup_completed'=>'boolean'];
}

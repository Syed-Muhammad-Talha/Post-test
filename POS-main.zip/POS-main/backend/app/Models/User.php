<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id', 'name', 'username', 'email', 'phone', 'role', 'status',
        'password', 'salt', 'last_login',
    ];

    protected $hidden = ['password', 'salt', 'remember_token'];

    protected $casts = [
        'last_login' => 'datetime',
    ];
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo; use Illuminate\Database\Eloquent\Relations\HasMany;
class RepairJob extends Model {
    protected $table='repair_jobs'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','job_number','customer_id','vehicle_id','date','mileage_in','customer_complaint','diagnosis','work_required','status','estimated_cost','final_cost','invoice_id','notes'];
    protected $casts=['estimated_cost'=>'decimal:2','final_cost'=>'decimal:2','date'=>'datetime'];
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function vehicle(): BelongsTo { return $this->belongsTo(Vehicle::class); }
    public function parts(): HasMany { return $this->hasMany(JobPart::class,'job_id'); }
    public function labours(): HasMany { return $this->hasMany(JobLabour::class,'job_id'); }
    public function photos(): HasMany { return $this->hasMany(JobPhoto::class,'job_id'); }
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Product extends Model {
    protected $keyType = 'string'; public $incrementing = false;
    protected $fillable = ['id','sku','name','category_id','supplier_id','brand','purchase_price','selling_price','current_quantity','min_stock_level','unit','shelf_location','description'];
    protected $casts = ['purchase_price'=>'decimal:2','selling_price'=>'decimal:2'];
    public function category(): BelongsTo { return $this->belongsTo(Category::class); }
    public function supplier(): BelongsTo { return $this->belongsTo(Supplier::class); }
}

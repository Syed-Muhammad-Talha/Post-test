<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class JobPhoto extends Model {
    protected $table='job_photos'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','job_id','photo_url','caption'];
    public function job(): BelongsTo { return $this->belongsTo(RepairJob::class,'job_id'); }
}

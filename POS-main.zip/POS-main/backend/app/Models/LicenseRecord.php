<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LicenseRecord extends Model {
    protected $table='license_records'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','name','license_number','issuing_authority','issue_date','expiry_date','renewal_cost','payment_date','payment_method','status','notes','attachment'];
    protected $casts=['renewal_cost'=>'decimal:2','issue_date'=>'datetime','expiry_date'=>'datetime','payment_date'=>'datetime'];
}

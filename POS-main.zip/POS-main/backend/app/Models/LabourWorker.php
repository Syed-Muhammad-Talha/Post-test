<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class LabourWorker extends Model {
    protected $table='labour_workers'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','name','phone','position','rate_type','rate_amount','status'];
    protected $casts=['rate_amount'=>'decimal:2'];
    public function payments(): HasMany { return $this->hasMany(LabourPayment::class,'worker_id'); }
}

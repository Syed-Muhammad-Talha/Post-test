<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo; use Illuminate\Database\Eloquent\Relations\HasMany;
class Purchase extends Model {
    protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','invoice_number','supplier_id','date','total_amount','notes','created_by'];
    protected $casts=['total_amount'=>'decimal:2','date'=>'datetime'];
    public function supplier(): BelongsTo { return $this->belongsTo(Supplier::class); }
    public function items(): HasMany { return $this->hasMany(PurchaseItem::class); }
}

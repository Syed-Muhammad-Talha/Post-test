<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Payment extends Model {
    protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','invoice_id','amount','payment_date','payment_method','reference_number','received_by','notes'];
    protected $casts=['amount'=>'decimal:2','payment_date'=>'datetime'];
    public function invoice(): BelongsTo { return $this->belongsTo(Invoice::class); }
}

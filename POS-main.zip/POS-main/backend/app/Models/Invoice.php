<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo; use Illuminate\Database\Eloquent\Relations\HasMany;
class Invoice extends Model {
    protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','invoice_number','job_card_id','customer_id','vehicle_id','date','parts_total','labour_total','services_total','parts_cost','labour_cost','services_cost','discount','tax_rate','tax_amount','grand_total','paid_amount','balance_due','payment_status','payment_method','notes'];
    protected $casts=['parts_total'=>'decimal:2','labour_total'=>'decimal:2','services_total'=>'decimal:2','parts_cost'=>'decimal:2','labour_cost'=>'decimal:2','services_cost'=>'decimal:2','discount'=>'decimal:2','tax_rate'=>'decimal:2','tax_amount'=>'decimal:2','grand_total'=>'decimal:2','paid_amount'=>'decimal:2','balance_due'=>'decimal:2','date'=>'datetime'];
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function vehicle(): BelongsTo { return $this->belongsTo(Vehicle::class); }
    public function items(): HasMany { return $this->hasMany(InvoiceItem::class); }
    public function payments(): HasMany { return $this->hasMany(Payment::class); }
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class Customer extends Model {
    protected $keyType = 'string'; public $incrementing = false;
    protected $fillable = ['id','full_name','phone','alternate_phone','email','address','notes'];
    public function vehicles(): HasMany { return $this->hasMany(Vehicle::class); }
}

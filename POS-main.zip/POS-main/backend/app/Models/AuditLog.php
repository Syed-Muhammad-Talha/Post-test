<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class AuditLog extends Model {
    protected $table='audit_logs'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','user_id','action','entity_type','entity_id','details','ip_address'];
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}

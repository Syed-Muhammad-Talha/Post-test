<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Expense extends Model {
    protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','title','category','type','amount','date','payment_method','status','paid_by','recipient','receipt_number','notes','attachment','void_reason','linked_entity_id','linked_entity_type'];
    protected $casts=['amount'=>'decimal:2','date'=>'datetime'];
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class InvoiceItem extends Model {
    protected $table='invoice_items'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','invoice_id','type','product_id','name','quantity','unit_price','total_price','unit_cost','total_cost'];
    protected $casts=['unit_price'=>'decimal:2','total_price'=>'decimal:2','unit_cost'=>'decimal:2','total_cost'=>'decimal:2'];
    public function invoice(): BelongsTo { return $this->belongsTo(Invoice::class); }
    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
}

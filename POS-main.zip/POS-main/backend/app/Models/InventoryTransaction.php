<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class InventoryTransaction extends Model {
    protected $table='inventory_transactions'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','product_id','type','quantity','unit_cost','reference_id','notes'];
    protected $casts=['unit_cost'=>'decimal:2'];
    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
}

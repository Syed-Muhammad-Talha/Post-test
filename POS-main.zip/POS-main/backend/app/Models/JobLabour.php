<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class JobLabour extends Model {
    protected $table='job_labours'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','job_id','worker_id','units','cost_to_shop','customer_charge','notes'];
    protected $casts=['cost_to_shop'=>'decimal:2','customer_charge'=>'decimal:2'];
    public function job(): BelongsTo { return $this->belongsTo(RepairJob::class,'job_id'); }
    public function worker(): BelongsTo { return $this->belongsTo(LabourWorker::class,'worker_id'); }
}

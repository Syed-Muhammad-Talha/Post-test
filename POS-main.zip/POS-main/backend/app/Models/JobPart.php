<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class JobPart extends Model {
    protected $table='job_parts'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','job_id','product_id','quantity','unit_cost','unit_price','total_cost','total_price'];
    protected $casts=['unit_cost'=>'decimal:2','unit_price'=>'decimal:2','total_cost'=>'decimal:2','total_price'=>'decimal:2'];
    public function job(): BelongsTo { return $this->belongsTo(RepairJob::class,'job_id'); }
    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
}

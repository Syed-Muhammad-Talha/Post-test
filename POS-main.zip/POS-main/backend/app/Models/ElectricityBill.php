<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ElectricityBill extends Model {
    protected $table='electricity_bills'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','billing_month','month_label','bill_number','previous_reading','current_reading','units_consumed','bill_amount','paid_amount','issue_date','due_date','payment_date','payment_method','status','notes','attachment'];
    protected $casts=['previous_reading'=>'decimal:2','current_reading'=>'decimal:2','units_consumed'=>'decimal:2','bill_amount'=>'decimal:2','paid_amount'=>'decimal:2','issue_date'=>'datetime','due_date'=>'datetime','payment_date'=>'datetime'];
}

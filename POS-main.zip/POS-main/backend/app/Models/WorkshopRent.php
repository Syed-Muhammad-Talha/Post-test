<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class WorkshopRent extends Model {
    protected $table='workshop_rents'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','month','month_label','amount','paid_amount','payment_date','payment_method','status','notes','attachment'];
    protected $casts=['amount'=>'decimal:2','paid_amount'=>'decimal:2','payment_date'=>'datetime'];
}

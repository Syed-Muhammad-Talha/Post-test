<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class OilChange extends Model {
    protected $table='oil_changes'; protected $keyType='string'; public $incrementing=false;
    protected $fillable=['id','vehicle_id','customer_id','oil_product_id','service_date','current_mileage','next_recommended_mileage','next_recommended_date','oil_brand','oil_type','oil_quantity','oil_filter_part_number','technician_name','cost_price','selling_price','status','notes'];
    protected $casts=['oil_quantity'=>'decimal:2','cost_price'=>'decimal:2','selling_price'=>'decimal:2','service_date'=>'datetime','next_recommended_date'=>'datetime'];
    public function vehicle(): BelongsTo { return $this->belongsTo(Vehicle::class); }
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function oilProduct(): BelongsTo { return $this->belongsTo(Product::class,'oil_product_id'); }
}

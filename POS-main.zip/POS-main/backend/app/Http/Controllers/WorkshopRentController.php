<?php
namespace App\Http\Controllers;
use App\Models\WorkshopRent; use Illuminate\Http\Request; use Illuminate\Support\Str;
class WorkshopRentController extends Controller {
    public function index(){ return response()->json(['data'=>WorkshopRent::latest()->get()]); }
    public function store(Request $r){ $r->validate(['month'=>'required','month_label'=>'required','amount'=>'required']); $w=WorkshopRent::create(array_merge(['id'=>Str::uuid()->toString()], $r->only(['month','month_label','amount','paid_amount','payment_date','payment_method','status','notes','attachment']))); return response()->json(['data'=>$w,'message'=>'Rent record created'],201); }
    public function update(Request $r,$id){ $w=WorkshopRent::find($id); if(!$w) return response()->json(['message'=>'Not found'],404); $w->update($r->only(['amount','paid_amount','payment_date','payment_method','status','notes','attachment'])); return response()->json(['data'=>$w,'message'=>'Rent updated']); }
}

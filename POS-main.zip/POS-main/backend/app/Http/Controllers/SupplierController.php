<?php
namespace App\Http\Controllers;
use App\Models\Supplier; use Illuminate\Http\Request; use Illuminate\Support\Str;
class SupplierController extends Controller {
    public function index(){ return response()->json(['data'=>Supplier::all()]); }
    public function show($id){ $s=Supplier::find($id); if(!$s) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$s]); }
    public function store(Request $r){ $r->validate(['name'=>'required']); $s=Supplier::create(array_merge(['id'=>Str::uuid()->toString()],$r->only(['name','phone','email','address']))); return response()->json(['data'=>$s,'message'=>'Supplier created'],201); }
    public function update(Request $r,$id){ $s=Supplier::find($id); if(!$s) return response()->json(['message'=>'Not found'],404); $s->update($r->only(['name','phone','email','address'])); return response()->json(['data'=>$s,'message'=>'Supplier updated']); }
    public function destroy($id){ $s=Supplier::find($id); if(!$s) return response()->json(['message'=>'Not found'],404); $s->delete(); return response()->json(['message'=>'Supplier deleted']); }
}

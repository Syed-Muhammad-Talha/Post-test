<?php
namespace App\Http\Controllers;
use App\Models\Product; use Illuminate\Http\Request; use Illuminate\Support\Str;
class ProductController extends Controller {
    public function index(){ return response()->json(['data'=>Product::with(['category','supplier'])->get()]); }
    public function show($id){ $p=Product::with(['category','supplier'])->find($id); if(!$p) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$p]); }
    public function store(Request $r){ $r->validate(['sku'=>'required|unique:products','name'=>'required']); $p=Product::create(array_merge(['id'=>Str::uuid()->toString()],$r->only(['sku','name','category_id','supplier_id','brand','purchase_price','selling_price','current_quantity','min_stock_level','unit','shelf_location','description']))); return response()->json(['data'=>$p,'message'=>'Product created'],201); }
    public function update(Request $r,$id){ $p=Product::find($id); if(!$p) return response()->json(['message'=>'Not found'],404); $p->update($r->only(['sku','name','category_id','supplier_id','brand','purchase_price','selling_price','current_quantity','min_stock_level','unit','shelf_location','description'])); return response()->json(['data'=>$p,'message'=>'Product updated']); }
    public function destroy($id){ $p=Product::find($id); if(!$p) return response()->json(['message'=>'Not found'],404); $p->delete(); return response()->json(['message'=>'Product deleted']); }
}

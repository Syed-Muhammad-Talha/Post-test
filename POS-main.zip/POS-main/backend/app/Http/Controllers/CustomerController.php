<?php
namespace App\Http\Controllers;
use App\Models\Customer; use Illuminate\Http\Request; use Illuminate\Support\Str;
class CustomerController extends Controller {
    public function index(){ return response()->json(['data'=>Customer::all()]); }
    public function show($id){ $c=Customer::find($id); if(!$c) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$c]); }
    public function store(Request $r){ $r->validate(['full_name'=>'required','phone'=>'required']); $c=Customer::create(array_merge(['id'=>Str::uuid()->toString()],$r->only(['full_name','phone','alternate_phone','email','address','notes']))); return response()->json(['data'=>$c,'message'=>'Customer created'],201); }
    public function update(Request $r,$id){ $c=Customer::find($id); if(!$c) return response()->json(['message'=>'Not found'],404); $c->update($r->only(['full_name','phone','alternate_phone','email','address','notes'])); return response()->json(['data'=>$c,'message'=>'Customer updated']); }
    public function destroy($id){ $c=Customer::find($id); if(!$c) return response()->json(['message'=>'Not found'],404); $c->delete(); return response()->json(['message'=>'Customer deleted']); }
}

<?php
namespace App\Http\Controllers;
use App\Models\Vehicle; use Illuminate\Http\Request; use Illuminate\Support\Str;
class VehicleController extends Controller {
    public function index(){ return response()->json(['data'=>Vehicle::with('customer')->get()]); }
    public function show($id){ $v=Vehicle::with('customer')->find($id); if(!$v) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$v]); }
    public function store(Request $r){ $r->validate(['customer_id'=>'required','registration_number'=>'required','make'=>'required','model'=>'required']); $v=Vehicle::create(array_merge(['id'=>Str::uuid()->toString()],$r->only(['customer_id','registration_number','make','model','year','color','vin','engine_number','current_mileage','fuel_type','notes']))); return response()->json(['data'=>$v,'message'=>'Vehicle created'],201); }
    public function update(Request $r,$id){ $v=Vehicle::find($id); if(!$v) return response()->json(['message'=>'Not found'],404); $v->update($r->only(['customer_id','registration_number','make','model','year','color','vin','engine_number','current_mileage','fuel_type','notes'])); return response()->json(['data'=>$v,'message'=>'Vehicle updated']); }
    public function destroy($id){ $v=Vehicle::find($id); if(!$v) return response()->json(['message'=>'Not found'],404); $v->delete(); return response()->json(['message'=>'Vehicle deleted']); }
}

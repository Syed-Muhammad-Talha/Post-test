<?php
namespace App\Http\Controllers;
use App\Models\JobPart; use Illuminate\Http\Request; use Illuminate\Support\Str;
class JobPartController extends Controller {
    public function store(Request $r){ $r->validate(['job_id'=>'required','product_id'=>'required','quantity'=>'required']); $jp=JobPart::create(['id'=>Str::uuid()->toString(),'job_id'=>$r->job_id,'product_id'=>$r->product_id,'quantity'=>$r->quantity,'unit_cost'=>$r->unit_cost ?? 0,'unit_price'=>$r->unit_price ?? 0,'total_cost'=>$r->total_cost ?? 0,'total_price'=>$r->total_price ?? 0]); return response()->json(['data'=>$jp,'message'=>'Part added'],201); }
    public function destroy($id){ $jp=JobPart::find($id); if(!$jp) return response()->json(['message'=>'Not found'],404); $jp->delete(); return response()->json(['message'=>'Part removed']); }
}

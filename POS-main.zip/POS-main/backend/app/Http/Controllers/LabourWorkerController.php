<?php
namespace App\Http\Controllers;
use App\Models\LabourWorker; use App\Models\LabourPayment;
use Illuminate\Http\Request; use Illuminate\Support\Str;
class LabourWorkerController extends Controller {
    public function index(){ return response()->json(['data'=>LabourWorker::with('payments')->get()]); }
    public function store(Request $r){ $r->validate(['name'=>'required','phone'=>'required','position'=>'required']); $w=LabourWorker::create(['id'=>Str::uuid()->toString(),'name'=>$r->name,'phone'=>$r->phone,'position'=>$r->position,'rate_type'=>$r->rate_type ?? 'daily','rate_amount'=>$r->rate_amount ?? 0,'status'=>$r->status ?? 'active']); return response()->json(['data'=>$w,'message'=>'Worker created'],201); }
    public function update(Request $r,$id){ $w=LabourWorker::find($id); if(!$w) return response()->json(['message'=>'Not found'],404); $w->update($r->only(['name','phone','position','rate_type','rate_amount','status'])); return response()->json(['data'=>$w,'message'=>'Worker updated']); }
    public function destroy($id){ $w=LabourWorker::find($id); if(!$w) return response()->json(['message'=>'Not found'],404); $w->delete(); return response()->json(['message'=>'Worker deleted']); }
}

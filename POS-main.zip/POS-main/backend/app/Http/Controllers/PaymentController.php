<?php
namespace App\Http\Controllers;
use App\Models\Payment; use App\Models\Invoice;
use Illuminate\Http\Request; use Illuminate\Support\Str;
class PaymentController extends Controller {
    public function index(){ return response()->json(['data'=>Payment::with('invoice')->latest()->get()]); }
    public function store(Request $r){
        $r->validate(['invoice_id'=>'required','amount'=>'required','received_by'=>'required']);
        $p=Payment::create(['id'=>Str::uuid()->toString(),'invoice_id'=>$r->invoice_id,'amount'=>$r->amount,'payment_date'=>$r->payment_date ?? now(),'payment_method'=>$r->payment_method ?? 'Cash','reference_number'=>$r->reference_number,'received_by'=>$r->received_by,'notes'=>$r->notes]);
        $inv=Invoice::find($r->invoice_id);
        if($inv){ $inv->paid_amount += $r->amount; $inv->balance_due = max(0,$inv->grand_total - $inv->paid_amount); $inv->payment_status = $inv->balance_due <= 0 ? 'paid' : 'partial'; $inv->save(); }
        return response()->json(['data'=>$p,'message'=>'Payment recorded'],201);
    }
}

<?php
namespace App\Http\Controllers;
use App\Models\OilChange; use Illuminate\Http\Request; use Illuminate\Support\Str;
class OilChangeController extends Controller {
    public function index(){ return response()->json(['data'=>OilChange::with(['vehicle','customer','oilProduct'])->latest()->get()]); }
    public function store(Request $r){ $r->validate(['vehicle_id'=>'required','customer_id'=>'required','current_mileage'=>'required','oil_brand'=>'required','oil_type'=>'required','oil_quantity'=>'required','technician_name'=>'required']); $o=OilChange::create(array_merge(['id'=>Str::uuid()->toString()], $r->only(['vehicle_id','customer_id','oil_product_id','service_date','current_mileage','next_recommended_mileage','next_recommended_date','oil_brand','oil_type','oil_quantity','oil_filter_part_number','technician_name','cost_price','selling_price','status','notes']))); return response()->json(['data'=>$o,'message'=>'Oil change recorded'],201); }
}

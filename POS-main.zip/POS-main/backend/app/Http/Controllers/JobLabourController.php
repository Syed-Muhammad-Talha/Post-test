<?php
namespace App\Http\Controllers;
use App\Models\JobLabour; use Illuminate\Http\Request; use Illuminate\Support\Str;
class JobLabourController extends Controller {
    public function store(Request $r){ $r->validate(['job_id'=>'required','worker_id'=>'required']); $jl=JobLabour::create(['id'=>Str::uuid()->toString(),'job_id'=>$r->job_id,'worker_id'=>$r->worker_id,'units'=>$r->units ?? 1,'cost_to_shop'=>$r->cost_to_shop ?? 0,'customer_charge'=>$r->customer_charge ?? 0,'notes'=>$r->notes]); return response()->json(['data'=>$jl,'message'=>'Labour added'],201); }
    public function destroy($id){ $jl=JobLabour::find($id); if(!$jl) return response()->json(['message'=>'Not found'],404); $jl->delete(); return response()->json(['message'=>'Labour removed']); }
}

<?php
namespace App\Http\Controllers;
use App\Models\Invoice; use App\Models\InvoiceItem; use App\Models\Payment;
use Illuminate\Http\Request; use Illuminate\Support\Str; use Illuminate\Support\Facades\DB;
class InvoiceController extends Controller {
    public function index(){ return response()->json(['data'=>Invoice::with(['customer','vehicle','items','payments'])->latest()->get()]); }
    public function show($id){ $i=Invoice::with(['customer','vehicle','items','payments'])->find($id); if(!$i) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$i]); }
    public function store(Request $r){
        $r->validate(['customer_id'=>'required','grand_total'=>'required']);
        return DB::transaction(function() use($r){
            $i=Invoice::create(array_merge(['id'=>Str::uuid()->toString()], $r->only(['invoice_number','job_card_id','customer_id','vehicle_id','date','parts_total','labour_total','services_total','parts_cost','labour_cost','services_cost','discount','tax_rate','tax_amount','grand_total','paid_amount','balance_due','payment_status','payment_method','notes'])));
            foreach($r->items ?? [] as $it){
                InvoiceItem::create(['id'=>Str::uuid()->toString(),'invoice_id'=>$i->id,'type'=>$it['type'] ?? 'part','product_id'=>$it['product_id'] ?? null,'name'=>$it['name'],'quantity'=>$it['quantity'],'unit_price'=>$it['unit_price'],'total_price'=>$it['total_price'],'unit_cost'=>$it['unit_cost'] ?? 0,'total_cost'=>$it['total_cost'] ?? 0]);
            }
            return response()->json(['data'=>$i->load('items'),'message'=>'Invoice created'],201);
        });
    }
    public function update(Request $r,$id){ $i=Invoice::find($id); if(!$i) return response()->json(['message'=>'Not found'],404); $i->update($r->only(['payment_status','paid_amount','balance_due','notes'])); return response()->json(['data'=>$i,'message'=>'Invoice updated']); }
    public function destroy($id){ $i=Invoice::find($id); if(!$i) return response()->json(['message'=>'Not found'],404); $i->delete(); return response()->json(['message'=>'Invoice deleted']); }
}

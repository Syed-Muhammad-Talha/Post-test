<?php
namespace App\Http\Controllers;
use App\Models\RepairJob; use App\Models\JobPart; use App\Models\JobLabour; use App\Models\JobPhoto;
use Illuminate\Http\Request; use Illuminate\Support\Str;
class RepairJobController extends Controller {
    public function index(){ return response()->json(['data'=>RepairJob::with(['customer','vehicle','parts','labours','photos'])->latest()->get()]); }
    public function show($id){ $j=RepairJob::with(['customer','vehicle','parts','labours','photos'])->find($id); if(!$j) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$j]); }
    public function store(Request $r){
        $r->validate(['customer_id'=>'required','vehicle_id'=>'required','customer_complaint'=>'required']);
        $j=RepairJob::create(array_merge(['id'=>Str::uuid()->toString(),'job_number'=>'JOB-'.time()], $r->only(['customer_id','vehicle_id','date','mileage_in','customer_complaint','diagnosis','work_required','status','estimated_cost','final_cost','invoice_id','notes'])));
        return response()->json(['data'=>$j,'message'=>'Job created'],201);
    }
    public function update(Request $r,$id){ $j=RepairJob::find($id); if(!$j) return response()->json(['message'=>'Not found'],404); $j->update($r->only(['status','diagnosis','work_required','estimated_cost','final_cost','invoice_id','notes'])); return response()->json(['data'=>$j,'message'=>'Job updated']); }
    public function destroy($id){ $j=RepairJob::find($id); if(!$j) return response()->json(['message'=>'Not found'],404); $j->delete(); return response()->json(['message'=>'Job deleted']); }
}

<?php
namespace App\Http\Controllers;
use App\Models\GarageSetting; use Illuminate\Http\Request; use Illuminate\Support\Str;
class GarageSettingController extends Controller {
    public function show(){ $s=GarageSetting::first(); if(!$s){ $s=GarageSetting::create(['id'=>Str::uuid()->toString()]); } return response()->json(['data'=>$s]); }
    public function update(Request $r){ $s=GarageSetting::first(); if(!$s){ $s=GarageSetting::create(['id'=>Str::uuid()->toString()]); } $s->update($r->all()); return response()->json(['data'=>$s,'message'=>'Settings updated']); }
}

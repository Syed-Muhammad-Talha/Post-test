<?php
namespace App\Http\Controllers;
use App\Models\LabourPayment; use Illuminate\Http\Request; use Illuminate\Support\Str;
class LabourPaymentController extends Controller {
    public function index(){ return response()->json(['data'=>LabourPayment::with('worker')->latest()->get()]); }
    public function store(Request $r){ $r->validate(['worker_id'=>'required','amount'=>'required']); $p=LabourPayment::create(['id'=>Str::uuid()->toString(),'worker_id'=>$r->worker_id,'date'=>$r->date ?? now(),'amount'=>$r->amount,'payment_method'=>$r->payment_method ?? 'Cash','period_start'=>$r->period_start,'period_end'=>$r->period_end,'notes'=>$r->notes]); return response()->json(['data'=>$p,'message'=>'Payment recorded'],201); }
}

<?php
namespace App\Http\Controllers;
use App\Models\ElectricityBill; use Illuminate\Http\Request; use Illuminate\Support\Str;
class ElectricityBillController extends Controller {
    public function index(){ return response()->json(['data'=>ElectricityBill::latest()->get()]); }
    public function store(Request $r){ $r->validate(['billing_month'=>'required','month_label'=>'required','bill_amount'=>'required']); $e=ElectricityBill::create(array_merge(['id'=>Str::uuid()->toString()], $r->only(['billing_month','month_label','bill_number','previous_reading','current_reading','units_consumed','bill_amount','paid_amount','issue_date','due_date','payment_date','payment_method','status','notes','attachment']))); return response()->json(['data'=>$e,'message'=>'Bill created'],201); }
    public function update(Request $r,$id){ $e=ElectricityBill::find($id); if(!$e) return response()->json(['message'=>'Not found'],404); $e->update($r->only(['paid_amount','payment_date','payment_method','status','notes','attachment'])); return response()->json(['data'=>$e,'message'=>'Bill updated']); }
}

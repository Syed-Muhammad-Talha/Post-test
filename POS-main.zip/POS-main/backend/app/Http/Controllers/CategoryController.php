<?php
namespace App\Http\Controllers;
use App\Models\Category; use Illuminate\Http\Request; use Illuminate\Support\Str;
class CategoryController extends Controller {
    public function index(){ return response()->json(['data'=>Category::all()]); }
    public function store(Request $r){ $r->validate(['name'=>'required|unique:categories']); $c=Category::create(['id'=>Str::uuid()->toString(),'name'=>$r->name]); return response()->json(['data'=>$c,'message'=>'Category created'],201); }
    public function update(Request $r,$id){ $c=Category::find($id); if(!$c) return response()->json(['message'=>'Not found'],404); $c->update($r->only(['name'])); return response()->json(['data'=>$c,'message'=>'Category updated']); }
    public function destroy($id){ $c=Category::find($id); if(!$c) return response()->json(['message'=>'Not found'],404); $c->delete(); return response()->json(['message'=>'Category deleted']); }
}

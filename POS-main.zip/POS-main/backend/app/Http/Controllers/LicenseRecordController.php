<?php
namespace App\Http\Controllers;
use App\Models\LicenseRecord; use Illuminate\Http\Request; use Illuminate\Support\Str;
class LicenseRecordController extends Controller {
    public function index(){ return response()->json(['data'=>LicenseRecord::latest()->get()]); }
    public function store(Request $r){ $r->validate(['name'=>'required','license_number'=>'required','issuing_authority'=>'required','renewal_cost'=>'required']); $l=LicenseRecord::create(array_merge(['id'=>Str::uuid()->toString()], $r->only(['name','license_number','issuing_authority','issue_date','expiry_date','renewal_cost','payment_date','payment_method','status','notes','attachment']))); return response()->json(['data'=>$l,'message'=>'License created'],201); }
    public function update(Request $r,$id){ $l=LicenseRecord::find($id); if(!$l) return response()->json(['message'=>'Not found'],404); $l->update($r->only(['status','payment_date','payment_method','notes','attachment'])); return response()->json(['data'=>$l,'message'=>'License updated']); }
}

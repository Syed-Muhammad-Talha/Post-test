<?php
namespace App\Http\Controllers;
use App\Models\Expense; use Illuminate\Http\Request; use Illuminate\Support\Str;
class ExpenseController extends Controller {
    public function index(){ return response()->json(['data'=>Expense::latest()->get()]); }
    public function store(Request $r){ $r->validate(['title'=>'required','category'=>'required','amount'=>'required']); $e=Expense::create(array_merge(['id'=>Str::uuid()->toString()], $r->only(['title','category','type','amount','date','payment_method','status','paid_by','recipient','receipt_number','notes','attachment','void_reason','linked_entity_id','linked_entity_type']))); return response()->json(['data'=>$e,'message'=>'Expense created'],201); }
    public function update(Request $r,$id){ $e=Expense::find($id); if(!$e) return response()->json(['message'=>'Not found'],404); $e->update($r->only(['title','category','type','amount','date','payment_method','status','paid_by','recipient','receipt_number','notes','attachment','void_reason'])); return response()->json(['data'=>$e,'message'=>'Expense updated']); }
    public function destroy($id){ $e=Expense::find($id); if(!$e) return response()->json(['message'=>'Not found'],404); $e->delete(); return response()->json(['message'=>'Expense deleted']); }
}

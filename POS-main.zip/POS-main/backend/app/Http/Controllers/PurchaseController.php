<?php
namespace App\Http\Controllers;
use App\Models\Purchase; use App\Models\PurchaseItem; use App\Models\Product; use App\Models\InventoryTransaction;
use Illuminate\Http\Request; use Illuminate\Support\Str; use Illuminate\Support\Facades\DB;
class PurchaseController extends Controller {
    public function index(){ return response()->json(['data'=>Purchase::with(['supplier','items.product'])->get()]); }
    public function show($id){ $p=Purchase::with(['supplier','items.product'])->find($id); if(!$p) return response()->json(['message'=>'Not found'],404); return response()->json(['data'=>$p]); }
    public function store(Request $r){
        $r->validate(['supplier_id'=>'nullable','items'=>'required|array']);
        return DB::transaction(function() use($r){
            $p=Purchase::create(['id'=>Str::uuid()->toString(),'invoice_number'=>$r->invoice_number,'supplier_id'=>$r->supplier_id,'date'=>$r->date ?? now(),'total_amount'=>$r->total_amount ?? 0,'notes'=>$r->notes,'created_by'=>$r->created_by]);
            foreach($r->items as $it){
                PurchaseItem::create(['id'=>Str::uuid()->toString(),'purchase_id'=>$p->id,'product_id'=>$it['product_id'],'quantity'=>$it['quantity'],'unit_cost'=>$it['unit_cost'],'total_cost'=>$it['total_cost'] ?? ($it['quantity']*$it['unit_cost'])]);
                $prod=Product::find($it['product_id']);
                if($prod){ $prod->increment('current_quantity',$it['quantity']); }
                InventoryTransaction::create(['id'=>Str::uuid()->toString(),'product_id'=>$it['product_id'],'type'=>'purchase','quantity'=>$it['quantity'],'unit_cost'=>$it['unit_cost'],'reference_id'=>$p->id,'notes'=>$r->notes]);
            }
            return response()->json(['data'=>$p->load('items'),'message'=>'Purchase created'],201);
        });
    }
    public function destroy($id){ $p=Purchase::find($id); if(!$p) return response()->json(['message'=>'Not found'],404); $p->delete(); return response()->json(['message'=>'Purchase deleted']); }
}

<?php
namespace App\Http\Controllers;
use App\Models\InventoryTransaction; use App\Models\Product;
use Illuminate\Http\Request; use Illuminate\Support\Str;
class InventoryTransactionController extends Controller {
    public function index(){ return response()->json(['data'=>InventoryTransaction::with('product')->latest()->get()]); }
    public function store(Request $r){
        $r->validate(['product_id'=>'required','type'=>'required','quantity'=>'required|integer']);
        $t=InventoryTransaction::create(['id'=>Str::uuid()->toString(),'product_id'=>$r->product_id,'type'=>$r->type,'quantity'=>$r->quantity,'unit_cost'=>$r->unit_cost ?? 0,'reference_id'=>$r->reference_id,'notes'=>$r->notes]);
        $p=Product::find($r->product_id);
        if($p){
            if(in_array($r->type,['purchase','adjustment_in','return'])) $p->increment('current_quantity',$r->quantity);
            else $p->decrement('current_quantity',abs($r->quantity));
        }
        return response()->json(['data'=>$t,'message'=>'Transaction recorded'],201);
    }
}

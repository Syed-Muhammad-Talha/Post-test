import {
  Customer,
  Vehicle,
  Product,
  LabourWorker,
  JobCard,
  Invoice,
  PaymentRecord,
  LabourPayment,
  OilChangeRecord,
  ShopExpense,
  WorkshopRent,
  LicenseRecord,
  ElectricityBill,
  InventoryTransaction,
  ShopSettings,
  User,
  AuditLog,
  PaymentProof,
  InvoicePrintEvent,
  UserSessionRecord,
  RecordChangeEntry
} from '../types';

export const INITIAL_USERS: User[] = [];

export const INITIAL_SETTINGS: ShopSettings = {
  shopName: '',
  garageName: '',
  garageOwnerName: '',
  garagePhone: '',
  garageEmail: '',
  timezone: 'Asia/Dubai',
  privateMode: true,
  setupCompleted: true,
  tagline: 'Professional Automotive Repair & Workshop Management',
  phone: '',
  email: '',
  address: '',
  taxNumber: '',
  currency: 'AED',
  defaultTaxRate: 5,
  invoicePrefix: 'INV-',
  invoiceFooterNote: 'Thank you for your business! All repairs covered with standard warranty.',
  defaultOilChangeMonths: 6,
  defaultOilChangeKm: 10000,
  allowNegativeStock: false,
  lowStockThreshold: 10,
  trnNumber: '',
  dedLicenseNumber: '',
  rtaPermitNumber: '',
  dmEnvironmentalPermit: '',
  storageGraceHours: 72,
  dailyStorageFeeAED: 0,
  workmanshipWarrantyDays: 90,
  workmanshipWarrantyKm: 5000,
  enforcePolicePermitForAccidents: false
};

// ============================================================================
// 📦 EMPTY DATA STORES — Ready for user's own live records
// ============================================================================
export const INITIAL_CUSTOMERS: Customer[] = [];
export const INITIAL_VEHICLES: Vehicle[] = [];
export const INITIAL_PRODUCTS: Product[] = [];
export const INITIAL_LABOUR_WORKERS: LabourWorker[] = [];
export const INITIAL_JOB_CARDS: JobCard[] = [];
export const INITIAL_INVOICES: Invoice[] = [];
export const INITIAL_PAYMENTS: PaymentRecord[] = [];
export const INITIAL_LABOUR_PAYMENTS: LabourPayment[] = [];
export const INITIAL_OIL_CHANGES: OilChangeRecord[] = [];
export const INITIAL_RENTS: WorkshopRent[] = [];
export const INITIAL_LICENSES: LicenseRecord[] = [];
export const INITIAL_ELECTRICITY_BILLS: ElectricityBill[] = [];
export const INITIAL_EXPENSES: ShopExpense[] = [];
export const INITIAL_TRANSACTIONS: InventoryTransaction[] = [];
export const INITIAL_AUDIT_LOGS: AuditLog[] = [];
export const INITIAL_USER_SESSIONS: UserSessionRecord[] = [];
export const INITIAL_RECORD_CHANGES: RecordChangeEntry[] = [];
export const INITIAL_PRINT_HISTORY: InvoicePrintEvent[] = [];
export const INITIAL_PAYMENT_PROOFS: PaymentProof[] = [];

/**
 * API Service Client for Garage POS & Workshop Management
 * Interacts with Vercel serverless /api routes with JWT Bearer authentication.
 * File: src/services/api.ts
 */

const API_BASE = (import.meta as any).env?.VITE_API_BASE_URL || '/api';

function getAuthHeader(): Record<string, string> {
  // Only use the backend-issued JWT session for API authentication.
  const keys = ['umair_autocare_v2_session', 'automotive_garage_pos_clean_v1_session'];
  for (const key of keys) {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.token) {
          return { Authorization: `Bearer ${parsed.token}` };
        }
        if (parsed && parsed.accessToken) {
          return { Authorization: `Bearer ${parsed.accessToken}` };
        }
        if (typeof parsed === 'string') {
          return { Authorization: `Bearer ${parsed}` };
        }
      }
    } catch (e) {
      // Malformed JSON — ignore
    }
  }
  return {};
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...(options.headers || {})
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const errorMsg = data?.message || data?.error || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data?.data !== undefined ? data.data : data;
}

export const api = {
  // Health
  checkHealth: () => request<{ status: string; app: string; currency: string; timezone: string }>('/health'),

  // Auth
  login: (credentials: { identifier: string; password: string }) =>
    request<{ user: any; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: credentials.identifier,
        password: credentials.password
      })
    }),

  getCurrentUser: () => request<any>('/auth/me'),

  // Settings
  getSettings: () => request<any>('/settings'),
  updateSettings: (settings: any) =>
    request<any>('/settings', {
      method: 'PUT',
      body: JSON.stringify(settings)
    }),

  // Customers
  getCustomers: () => request<any[]>('/customers'),
  createCustomer: (customer: any) =>
    request<any>('/customers', {
      method: 'POST',
      body: JSON.stringify(customer)
    }),
  updateCustomer: (id: string, customer: any) =>
    request<any>(`/customers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(customer)
    }),
  deleteCustomer: (id: string) =>
    request<any>(`/customers/${id}`, {
      method: 'DELETE'
    }),

  // Vehicles
  getVehicles: () => request<any[]>('/vehicles'),
  createVehicle: (vehicle: any) =>
    request<any>('/vehicles', {
      method: 'POST',
      body: JSON.stringify(vehicle)
    }),
  updateVehicle: (id: string, vehicle: any) =>
    request<any>(`/vehicles/${id}`, {
      method: 'PUT',
      body: JSON.stringify(vehicle)
    }),

  // Products & Inventory
  getProducts: () => request<any[]>('/products'),
  createProduct: (product: any) =>
    request<any>('/products', {
      method: 'POST',
      body: JSON.stringify(product)
    }),
  updateProduct: (id: string, product: any) =>
    request<any>(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(product)
    }),
  adjustProductStock: (id: string, data: { delta: number; type?: string; reason?: string }) =>
    request<any>(`/products/${id}/stock`, {
      method: 'PATCH',
      body: JSON.stringify(data)
    }),

  // Repair Jobs
  getJobs: () => request<any[]>('/jobs'),
  createJob: (job: any) =>
    request<any>('/jobs', {
      method: 'POST',
      body: JSON.stringify(job)
    }),
  updateJob: (id: string, job: any) =>
    request<any>(`/jobs/${id}`, {
      method: 'PUT',
      body: JSON.stringify(job)
    }),

  // Invoices & POS
  getInvoices: () => request<any[]>('/invoices'),
  createInvoice: (invoice: any) =>
    request<any>('/invoices', {
      method: 'POST',
      body: JSON.stringify(invoice)
    }),
  updateInvoice: (id: string, invoice: any) =>
    request<any>(`/invoices/${id}`, {
      method: 'PUT',
      body: JSON.stringify(invoice)
    }),

  // Payments
  getPayments: () => request<any[]>('/payments'),
  createPayment: (payment: any) =>
    request<any>('/payments', {
      method: 'POST',
      body: JSON.stringify(payment)
    }),

  // Labour
  getLabourWorkers: () => request<any[]>('/labour/workers'),
  createLabourWorker: (worker: any) =>
    request<any>('/labour/workers', {
      method: 'POST',
      body: JSON.stringify(worker)
    }),
  getLabourPayments: () => request<any[]>('/labour/payments'),
  createLabourPayment: (payment: any) =>
    request<any>('/labour/payments', {
      method: 'POST',
      body: JSON.stringify(payment)
    }),
  updateLabourPayment: (id: string, payment: any) =>
    request<any>(`/labour/payments/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payment)
    }),
  deleteLabourPayment: (id: string) =>
    request<any>(`/labour/payments/${id}`, {
      method: 'DELETE'
    }),

  // Suppliers
  getSuppliers: () => request<any[]>('/suppliers'),
  createSupplier: (supplier: any) => request<any>('/suppliers', { method: 'POST', body: JSON.stringify(supplier) }),

  // Purchases
  getPurchases: () => request<any[]>('/purchases'),
  createPurchase: (purchase: any) => request<any>('/purchases', { method: 'POST', body: JSON.stringify(purchase) }),

  // Expenses
  getExpenses: () => request<any[]>('/expenses'),
  createExpense: (expense: any) => request<any>('/expenses', { method: 'POST', body: JSON.stringify(expense) }),

  // Oil Changes
  getOilChanges: () => request<any[]>('/oil-changes'),
  createOilChange: (oil: any) => request<any>('/oil-changes', { method: 'POST', body: JSON.stringify(oil) }),

  // Settings (alias)
  getAppSettings: () => request<any>('/settings'),
  updateAppSettings: (settings: any) => request<any>('/settings', { method: 'PUT', body: JSON.stringify(settings) }),

  // Document & Receipt Storage (Vercel Blob / Secure Payload)
  uploadDocument: (payload: {
    filename: string;
    mimeType: string;
    dataUrl: string;
    folder?: string;
    notes?: string;
    entityType?: string;
    entityId?: string;
  }) =>
    request<{
      url: string;
      pathname?: string;
      contentType: string;
      size: number;
      storageProvider: string;
      filename: string;
    }>('/uploads', {
      method: 'POST',
      body: JSON.stringify(payload)
    })
};

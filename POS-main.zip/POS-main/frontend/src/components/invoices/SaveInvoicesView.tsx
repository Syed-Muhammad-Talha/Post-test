import React, { useState } from 'react';
import {
    Receipt,
    Plus,
    Search,
    Users,
    Car,
    Save,
    AlertCircle,
    CheckCircle
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Invoice, PaymentMethod, PaymentStatus, Customer, Vehicle } from '../../types';
import { formatAED, formatDate } from '../../utils/formatters';

export const SaveInvoicesView: React.FC = () => {
    const {
        invoices,
        customers,
        vehicles,
        createInvoice,
        setActiveView
    } = useShop();

    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
    const [selectedVehicleId, setSelectedVehicleId] = useState<string>('');
    const [invoiceNumber, setInvoiceNumber] = useState('');
    const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
    const [partsTotal, setPartsTotal] = useState(0);
    const [labourTotal, setLabourTotal] = useState(0);
    const [servicesTotal, setServicesTotal] = useState(0);
    const [discount, setDiscount] = useState(0);
    const [taxRate, setTaxRate] = useState(0);
    const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
    const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Unpaid');
    const [notes, setNotes] = useState('');
    const [saving, setSaving] = useState(false);
    const [lastSaved, setLastSaved] = useState<Invoice | null>(null);

    const filteredCustomers = customers.filter(c =>
        c.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.phone.includes(searchTerm)
    );

    const filteredVehicles = vehicles.filter(v =>
        v.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.model.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const subtotal = partsTotal + labourTotal + servicesTotal - discount;
    const taxAmount = subtotal * (taxRate / 100);
    const grandTotal = subtotal + taxAmount;
    const paidAmount = paymentStatus === 'Paid' ? grandTotal : 0;
    const balanceDue = grandTotal - paidAmount;

    const generateInvoiceNumber = () => {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = invoices.filter(inv => inv.date.startsWith(today.toISOString().slice(0, 10))).length + 1;
        return `INV-${dateStr}-${String(count).padStart(3, '0')}`;
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedCustomerId || !selectedVehicleId) {
            alert('Please select both a customer and a vehicle.');
            return;
        }

        setSaving(true);
        const newInvoice: Omit<Invoice, 'id' | 'createdDate'> = {
            invoiceNumber: invoiceNumber || generateInvoiceNumber(),
            date,
            dueDate: date,
            customerId: selectedCustomerId,
            vehicleId: selectedVehicleId,
            items: [],
            partsTotal,
            labourTotal,
            servicesTotal,
            subtotal,
            partsCost: 0,
            labourCost: 0,
            servicesCost: 0,
            discount,
            discountType: 'fixed',
            taxRate,
            taxAmount,
            grandTotal,
            paidAmount,
            balanceDue,
            paymentMethod,
            paymentStatus,
            notes: notes || undefined
        };

        const saved = createInvoice(newInvoice);
        setLastSaved(saved);
        setSaving(false);

        // Reset form
        setInvoiceNumber('');
        setSelectedCustomerId('');
        setSelectedVehicleId('');
        setPartsTotal(0);
        setLabourTotal(0);
        setServicesTotal(0);
        setDiscount(0);
        setTaxRate(0);
        setNotes('');
        setPaymentStatus('Unpaid');
    };

    return (
        <div className="space-y-4">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#DCDDD9] pb-3">
                <div>
                    <div className="flex items-center gap-2">
                        <h1 className="text-xl font-bold tracking-tight text-[#202321]">
                            Save New Invoice
                        </h1>
                        <span className="rounded bg-[#E8F0EC] px-2 py-0.5 text-[10px] font-bold text-[#1B4D3E] uppercase tracking-wide">
                            Billing & Receivables
                        </span>
                    </div>
                    <p className="text-xs text-[#6B706D] mt-0.5">
                        Create and save customer invoices for parts, labour, and services rendered.
                    </p>
                </div>

                <button
                    onClick={() => setActiveView('invoices')}
                    className="inline-flex items-center gap-1.5 rounded bg-[#1B4D3E] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#153E32] transition-colors shadow-xs"
                >
                    <Receipt className="h-3.5 w-3.5" />
                    <span>View Invoices Ledger</span>
                </button>
            </div>

            {/* Last Saved Notification */}
            {lastSaved && (
                <div className="rounded border border-[#BBF7D0] bg-[#F0FDF4] p-3 flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-[#15803D]" />
                    <span className="text-xs text-[#15803D] font-medium">
                        Invoice #{lastSaved.invoiceNumber} saved successfully — {formatAED(lastSaved.grandTotal)}
                    </span>
                </div>
            )}

            {/* Invoice Form */}
            <form onSubmit={handleSave} className="rounded border border-[#DCDDD9] bg-white p-4 sm:p-6 shadow-xs space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {/* Customer */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Customer
                        </label>
                        <select
                            value={selectedCustomerId}
                            onChange={e => setSelectedCustomerId(e.target.value)}
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        >
                            <option value="">Select Customer</option>
                            {filteredCustomers.map(c => (
                                <option key={c.id} value={c.id}>
                                    {c.fullName} — {c.phone}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Vehicle */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Vehicle
                        </label>
                        <select
                            value={selectedVehicleId}
                            onChange={e => setSelectedVehicleId(e.target.value)}
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        >
                            <option value="">Select Vehicle</option>
                            {filteredVehicles.map(v => (
                                <option key={v.id} value={v.id}>
                                    {v.registrationNumber} — {v.make} {v.model}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Invoice Number */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Invoice #
                        </label>
                        <input
                            type="text"
                            value={invoiceNumber}
                            onChange={e => setInvoiceNumber(e.target.value)}
                            placeholder="Auto-generated if empty"
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs font-mono text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Date */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Date
                        </label>
                        <input
                            type="date"
                            value={date}
                            onChange={e => setDate(e.target.value)}
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Parts Total */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Parts Total (AED)
                        </label>
                        <input
                            type="number"
                            value={partsTotal}
                            onChange={e => setPartsTotal(Number(e.target.value) || 0)}
                            min="0"
                            step="0.01"
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs font-mono text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Labour Total */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Labour Total (AED)
                        </label>
                        <input
                            type="number"
                            value={labourTotal}
                            onChange={e => setLabourTotal(Number(e.target.value) || 0)}
                            min="0"
                            step="0.01"
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs font-mono text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Services Total */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Services Total (AED)
                        </label>
                        <input
                            type="number"
                            value={servicesTotal}
                            onChange={e => setServicesTotal(Number(e.target.value) || 0)}
                            min="0"
                            step="0.01"
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs font-mono text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Discount */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Discount (AED)
                        </label>
                        <input
                            type="number"
                            value={discount}
                            onChange={e => setDiscount(Number(e.target.value) || 0)}
                            min="0"
                            step="0.01"
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs font-mono text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Tax Rate */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Tax Rate (%)
                        </label>
                        <input
                            type="number"
                            value={taxRate}
                            onChange={e => setTaxRate(Number(e.target.value) || 0)}
                            min="0"
                            step="0.1"
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs font-mono text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>

                    {/* Payment Method */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Payment Method
                        </label>
                        <select
                            value={paymentMethod}
                            onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        >
                            <option value="Cash">Cash (AED)</option>
                            <option value="Card">Credit / Debit Card</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Other">Corporate Cheque</option>
                        </select>
                    </div>

                    {/* Payment Status */}
                    <div className="col-span-1 sm:col-span-1">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Payment Status
                        </label>
                        <select
                            value={paymentStatus}
                            onChange={e => setPaymentStatus(e.target.value as PaymentStatus)}
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        >
                            <option value="Unpaid">Unpaid</option>
                            <option value="Partially Paid">Partially Paid</option>
                            <option value="Paid">Paid</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>

                    {/* Notes */}
                    <div className="col-span-1 sm:col-span-2 lg:col-span-3">
                        <label className="block text-[11px] font-semibold text-[#6B706D] mb-1 uppercase tracking-wider">
                            Notes
                        </label>
                        <textarea
                            value={notes}
                            onChange={e => setNotes(e.target.value)}
                            rows={2}
                            placeholder="Optional notes about this invoice..."
                            className="w-full rounded border border-[#DCDDD9] bg-white px-2.5 py-1.5 text-xs text-[#202321] focus:border-[#1B4D3E] focus:outline-none"
                        />
                    </div>
                </div>

                {/* Summary Ribbon */}
                <div className="rounded border border-[#DCDDD9] bg-[#F5F5F3] p-3 sm:p-4 divide-y sm:divide-y-0 sm:divide-x divide-[#DCDDD9] grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="p-2">
                        <div className="text-[10px] font-semibold text-[#6B706D] uppercase tracking-wider">Subtotal</div>
                        <div className="mt-0.5 text-sm font-bold font-mono text-[#202321]">{formatAED(subtotal)}</div>
                    </div>
                    <div className="p-2">
                        <div className="text-[10px] font-semibold text-[#6B706D] uppercase tracking-wider">Tax</div>
                        <div className="mt-0.5 text-sm font-bold font-mono text-[#202321]">{formatAED(taxAmount)}</div>
                    </div>
                    <div className="p-2">
                        <div className="text-[10px] font-semibold text-[#6B706D] uppercase tracking-wider">Grand Total</div>
                        <div className="mt-0.5 text-sm font-bold font-mono text-[#1B4D3E]">{formatAED(grandTotal)}</div>
                    </div>
                    <div className="p-2">
                        <div className="text-[10px] font-semibold text-[#6B706D] uppercase tracking-wider">Balance Due</div>
                        <div className="mt-0.5 text-sm font-bold font-mono text-[#B45309]">{formatAED(balanceDue)}</div>
                    </div>
                </div>

                {/* Submit Button */}
                <div className="flex justify-end">
                    <button
                        type="submit"
                        disabled={saving || !selectedCustomerId || !selectedVehicleId}
                        className={`inline-flex items-center gap-1.5 rounded px-4 py-1.5 text-xs font-semibold transition-colors shadow-xs ${saving || !selectedCustomerId || !selectedVehicleId
                                ? 'bg-[#DCDDD9] text-[#6B706D] cursor-not-allowed'
                                : 'bg-[#1B4D3E] text-white hover:bg-[#153E32]'
                            }`}
                    >
                        {saving ? (
                            <>
                                <Save className="h-3.5 w-3.5 animate-spin" />
                                <span>Saving...</span>
                            </>
                        ) : (
                            <>
                                <Save className="h-3.5 w-3.5" />
                                <span>Save Invoice</span>
                            </>
                        )}
                    </button>
                </div>
            </form>

            {/* Quick Select Helpers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="rounded border border-[#DCDDD9] bg-white p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <Users className="h-3.5 w-3.5 text-[#6B706D]" />
                        <span className="text-xs font-semibold text-[#202321]">Available Customers</span>
                    </div>
                    <div className="text-xs text-[#6B706D]">
                        {customers.length} customer(s) on file
                    </div>
                </div>
                <div className="rounded border border-[#DCDDD9] bg-white p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <Car className="h-3.5 w-3.5 text-[#6B706D]" />
                        <span className="text-xs font-semibold text-[#202321]">Available Vehicles</span>
                    </div>
                    <div className="text-xs text-[#6B706D]">
                        {vehicles.length} vehicle(s) on file
                    </div>
                </div>
            </div>
        </div>
    );
};
